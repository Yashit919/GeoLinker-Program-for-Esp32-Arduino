/*
 * GeoLinker GPS Tracker (ESP32)
 * -----------------------------------------------------------
 * Reads NMEA data from a GPS module over UART and uploads
 * location to the GeoLinker cloud over WiFi. Supports offline
 * buffering and auto-reconnect.
 *
 * Wiring (GPS module -> ESP32):
 *   GPS TX  -> GPIO 16 (ESP32 RX)
 *   GPS RX  -> GPIO 17 (ESP32 TX)
 *   VCC     -> 3V3 or 5V (check your module)
 *   GND     -> GND
 *
 * Setup: copy secrets.example.h to secrets.h and fill in your
 * WiFi credentials and GeoLinker API key.
 *
 * License: MIT
 */

#include <GeoLinker.h>
#include "secrets.h"   // WIFI_SSID, WIFI_PASSWORD, GEOLINKER_API_KEY

// ---------------- GPS UART ----------------
constexpr uint8_t  GPS_RX   = 16;   // ESP32 RX <- GPS TX
constexpr uint8_t  GPS_TX   = 17;   // ESP32 TX -> GPS RX
constexpr uint32_t GPS_BAUD = 9600;

HardwareSerial gpsSerial(1);

// ---------------- Tracker config ----------------
const char* deviceID = "ESP-32_Tracker";

constexpr uint16_t updateInterval        = 2;     // seconds between uploads
constexpr bool     enableOfflineStorage  = true;
constexpr uint8_t  offlineBufferLimit    = 20;    // max buffered points
constexpr bool     enableAutoReconnect   = true;

// Timezone offset from UTC (India = +5:30)
constexpr int8_t timeOffsetHours   = 5;
constexpr int8_t timeOffsetMinutes = 30;

GeoLinker geo;

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n[GeoLinker] Starting tracker...");

  gpsSerial.begin(GPS_BAUD, SERIAL_8N1, GPS_RX, GPS_TX);

  geo.begin(gpsSerial);
  geo.setApiKey(GEOLINKER_API_KEY);
  geo.setDeviceID(deviceID);
  geo.setUpdateInterval_seconds(updateInterval);
  geo.setDebugLevel(DEBUG_BASIC);
  geo.enableOfflineStorage(enableOfflineStorage);
  geo.enableAutoReconnect(enableAutoReconnect);
  geo.setOfflineBufferLimit(offlineBufferLimit);
  geo.setTimeOffset(timeOffsetHours, timeOffsetMinutes);

  geo.setNetworkMode(GEOLINKER_WIFI);
  geo.setWiFiCredentials(WIFI_SSID, WIFI_PASSWORD);

  Serial.println("[GeoLinker] Connecting to WiFi...");
  geo.connectToWiFi();
}

void loop() {
  // GeoLinker handles GPS parsing, uploads and buffering internally.
  // The return value is a status code; see the library docs.
  uint8_t status = geo.loop();
  (void)status;  // replace with your own handling if needed
}
