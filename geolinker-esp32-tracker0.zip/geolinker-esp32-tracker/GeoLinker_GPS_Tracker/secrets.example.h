// Copy this file to "secrets.h" and fill in your real values.
// secrets.h is git-ignored so your credentials are never committed.

#pragma once

#define WIFI_SSID          "yourSSID"
#define WIFI_PASSWORD      "yourPassword"
#define GEOLINKER_API_KEY  "your-geolinker-api-key"
